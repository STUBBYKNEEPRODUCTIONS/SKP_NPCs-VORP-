Config = {}


Config.npc = {
    { 
        npcmodel = 'U_M_M_NbxGeneralStoreOwner_01', 
        coords = {x=-324.48, y=803.58, z=117.00, h=291.75, r=20}, 
        placeOnGround = false, 
    }, -- Valentine General Store
	---ADD MORE NPC'S HERE AS NEEDED
}
