fx_version 'cerulean'
game 'rdr3'

rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'

author 'IwearRompers'
description "SKP_NPCs - Simple proximity NPC spawner for RedM (VORP compatible)"
version '1.0.0'


client_scripts {
  "config.lua",
  "client.lua"
}

dependencies {
  "vorp_core"
}