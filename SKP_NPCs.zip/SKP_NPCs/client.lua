local Core = exports.vorp_core:GetCore()

local spawned = {} -- [index] = pedHandle

local function loadModel(modelName)
    if not modelName or modelName == "" then return nil end

    local hash = joaat(modelName)

    if not IsModelValid(hash) then
        print(("[SKP_NPCs] Invalid model: %s"):format(tostring(modelName)))
        return nil
    end

    if not HasModelLoaded(hash) then
        RequestModel(hash)

        local timeout = GetGameTimer() + 20000
        while not HasModelLoaded(hash) do
            Wait(100)
            if GetGameTimer() > timeout then
                print(("[SKP_NPCs] Model load timeout: %s"):format(tostring(modelName)))
                return nil
            end
        end
    end

    return hash
end

local function spawnNpc(i, data)
    if spawned[i] and DoesEntityExist(spawned[i]) then return end
    if not data or not data.coords or not data.npcmodel then return end

    local c = data.coords
    if not c.x or not c.y or not c.z then return end

    local modelHash = loadModel(data.npcmodel)
    if not modelHash then return end

    local ped = CreatePed(modelHash, c.x, c.y, c.z, c.h or 0.0, false, false, false, false)

    local timeout = GetGameTimer() + 20000
    while not DoesEntityExist(ped) do
        Wait(100)
        if GetGameTimer() > timeout then
            print(("[SKP_NPCs] CreatePed timeout (index %s, model %s)"):format(
                tostring(i), tostring(data.npcmodel)
            ))
            return
        end
    end

    SetRandomOutfitVariation(ped, true)

    if data.placeOnGround then
        PlaceEntityOnGroundProperly(ped)
    end

    SetEntityCanBeDamaged(ped, false)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    FreezeEntityPosition(ped, true)
    SetPedCanRagdoll(ped, false)

    spawned[i] = ped
end

local function despawnNpc(i)
    local ped = spawned[i]
    if ped and DoesEntityExist(ped) then
        DeleteEntity(ped)
    end
    spawned[i] = nil
end

CreateThread(function()
    while PlayerPedId() == 0 do Wait(500) end
    while not NetworkIsSessionStarted() do Wait(500) end

    while true do
        local sleep = 1000

        if Config and Config.npc then
            local playerCoords = GetEntityCoords(PlayerPedId())

            for i, data in ipairs(Config.npc) do
                local c = data.coords
                if c then
                    local radius = (c.r and tonumber(c.r)) or 20.0
                    local dist = #(playerCoords - vector3(c.x, c.y, c.z))

                    if dist < radius then
                        sleep = 0
                        spawnNpc(i, data)
                    elseif spawned[i] then
                        despawnNpc(i)
                    end
                end
            end
        else
            Wait(2000)
        end

        Wait(sleep)
    end
end)

AddEventHandler("onResourceStop", function(res)
    if res ~= GetCurrentResourceName() then return end
    for i, _ in pairs(spawned) do
        despawnNpc(i)
    end
end)
